export const userData = [
    {
        name: "vivek chaturvedi",
        emailid: "vc8bp1@gmail.com",
        isAdmin: true,
        id: 1
    },
    {
        name: "tapan gosh",
        emailid: "vc8bp2@gmail.com",
        isAdmin: true,
        id: 2
    },
    {
        name: "mehul rai",
        emailid: "vc8bp3@gmail.com",
        isAdmin: false,
        id: 3
    },
    {
        name: "ashish shah",
        emailid: "vc8bp4@gmail.com",
        isAdmin: true,
        id: 4
    },
    {
        name: "farn khan",
        emailid: "vc8bp5@gmail.com",
        isAdmin: false,
        id: 5
    },
    {
        name: "name surname",
        emailid: "vc8bp6@gmail.com",
        isAdmin: true,
        id: 6
    },
]